import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";
import axios from 'axios'
import ReactHtmlParser from "react-html-parser";
import layout from "simple-keyboard-layouts/build/layouts/russian";

import Keyboard from 'react-simple-keyboard';
import 'react-simple-keyboard/build/css/index.css';

class App extends React.Component {
  constructor(props) {
    super(props);

  this.state = {
    questions: [],
    actualq: {
      a:{id:"", option:"", audio:""},
      b:{id:"", option:"", audio:""},
      c:{id:"", option:"", audio:""},
      d:{id:"", option:"", audio:""},
      option:""
     
    },
    index:0,
    result:"",
    mode:0,
    option:"",
    user_input:"",
    op:"",
    correct:0,
    failed:0
  }
  this.checkq=this.checkq.bind(this);
  this.getq=this.getq.bind(this);
  this.getw=this.getw.bind(this);
  this.selop=this.selop.bind(this);
  this.pquestion=this.pquestion.bind(this);
  this.sbut=this.sbut.bind(this);
  this.textchange=this.textchange.bind(this);
  this.similarity=this.similarity.bind(this);
  this.editDistance=this.editDistance.bind(this);
  this.writecheck=this.writecheck.bind(this);
  this.dstats=this.dstats.bind(this);
  this.playSound=this.playSound.bind(this);
  }

  componentDidMount() {
    fetch('http://127.0.0.1:5000/gentest/a1_a2')
    .then((response) => response.json())
    .then(qlist => {
        this.setState({ questions: qlist, actualq: qlist[0] });
    });
    
  }

  pquestion(params){
    if(params.translation != null){
      console.log(params)
      axios.post('http://127.0.0.1:5000/check', JSON.stringify(params) ,).then(res => {
        console.log(res.data.result)
        if(res.data.result === false){

          this.setState({"result":"<font color='red'>Wrong</font>", "failed":this.state.failed+1} )
        }
        else{
          this.setState({"result":"<font color='green'>Right!</font>","correct":this.state.correct+1})
        }
    })
    .catch((error) => {
      console.log(error)
  })
    }
    
  }

  checkq() {
    const qs = this.state.questions;
    let index = this.state.index;
    
    if (index == 19){
      index = 0
    }
    
    this.setState(
      {actualq: qs[index+1], index:index+1, result:"", user_input:"", option:""}
    )

  }

  selop(p, option) {

    if(p !== "" && option !== ""){
      this.playSound(p)
      const params = {
        "translation": p,
        "option": option,
        "user_id": 1,
        "lang": 'ru'
      }

      this.pquestion(params)

    }
    
  }
//<input className="listen" type="button" value="listen" onClick={this.playSound(a.id)} 
  getq() {
    const actualq = this.state.actualq;
    const tasks = Object.values(actualq);
    const a = actualq.a
    const b = actualq.b
    const c = actualq.c
    const d = actualq.d
    return (
      <div>
      <div className='question'>
      <b>Word? <font color='black'>{actualq.question}</font></b>
      <ul>
        <li  >{a.option}  <input type="radio" name="name" value={a.id} onClick={()=>{this.selop(a.id, actualq.question)}} /> </li>
        <li  >{b.option}  <input type="radio" name="name" value={b.id} onClick={()=>{this.selop(b.id, actualq.question)}}  /> </li>
        <li  >{c.option}  <input type="radio" name="name" value={c.id} onClick={()=>{this.selop(c.id, actualq.question)}}  /> </li>
        <li  >{d.option}  <input type="radio" name="name" value={d.id} onClick={()=>{this.selop(d.id, actualq.question)}}  /> </li>
      </ul>
    <p>Result: {ReactHtmlParser(this.state.result)} </p>
      <hr />
      <input type="button" value="next!"  onClick={this.checkq}/>
      </div>
      </div>
      
    )

  }
  editDistance(s1, s2) {
    s1 = s1.toLowerCase();
    s2 = s2.toLowerCase();
  
    var costs = new Array();
    for (var i = 0; i <= s1.length; i++) {
      var lastValue = i;
      for (var j = 0; j <= s2.length; j++) {
        if (i == 0)
          costs[j] = j;
        else {
          if (j > 0) {
            var newValue = costs[j - 1];
            if (s1.charAt(i - 1) != s2.charAt(j - 1))
              newValue = Math.min(Math.min(newValue, lastValue),
                costs[j]) + 1;
            costs[j - 1] = lastValue;
            lastValue = newValue;
          }
        }
      }
      if (i > 0)
        costs[s2.length] = lastValue;
    }
    return costs[s2.length];
  }

  similarity(s1, s2) {
    var longer = s1;
    var shorter = s2;
    if (s1.length < s2.length) {
      longer = s2;
      shorter = s1;
    }
    var longerLength = longer.length;
    if (longerLength == 0) {
      return 1.0;
    }
    return (longerLength - this.editDistance(longer, shorter)) / parseFloat(longerLength);
  }

  writecheck(){    
    this.selop(this.state.op, this.state.actualq.question);

  }

  textchange(event) {
    const actualq = this.state.actualq;
    const tasks = Object.values(actualq);
    const a = actualq.a
    const b = actualq.b
    const c = actualq.c
    const d = actualq.d
    let w = "";
    // similarity a
    let simil_a = this.similarity(actualq.a.option, event.target.value);
    let op = "";
    if(simil_a > 0.70){
      w = actualq.a.option;
      if(simil_a > 0.99){
        op = actualq.a.id;

      }
    }

    // similarity b
    let simil_b = this.similarity(actualq.b.option, event.target.value);
    if(simil_b > 0.70){
      w = actualq.b.option;
      if(simil_b > 0.99){
        op = actualq.b.id;
      }
    }

    // similarity c
    let simil_c = this.similarity(actualq.c.option, event.target.value);
    if(simil_c > 0.70){
      w = actualq.c.option;
      if(simil_c > 0.99){
        op = actualq.c.id;
      }
    }

    // similarity d
    let simil_d = this.similarity(actualq.d.option, event.target.value);
    if(simil_d > 0.70){
      w = actualq.d.option;
      if(simil_d > 0.99){
        op = actualq.d.id;
      }
    }

    this.setState({
      user_input:event.target.value,
      option:w,
      op:op
    })

  }
  onKeyPress = (button) => {
    
    console.log("Button pressed", button);
    document.getElementById('ink').value = document.getElementById('ink').value + button

  }

  onChange = (button) => {
    //document.querySelector(".input").value = input;
  }
  getw() {
    const actualq = this.state.actualq;
    const tasks = Object.values(actualq);
    const a = actualq.a
    const b = actualq.b
    const c = actualq.c
    const d = actualq.d
    
    return (
      <div>
      <div className='question'>
      <b>Word? <font color='black'>{actualq.question}</font></b>
      <div><p className='suggested'>option: {this.state.option}</p></div>
      <div><input className='input' type="text" id="ink" value={this.state.user_input} onChange={this.textchange}></input><input onClick={this.writecheck} className="check" type="button" value="check"></input></div>
      <br />
      <Keyboard
        onKeyPress={this.onKeyPress}
        physicalKeyboardHighlight="true"
        layout = {layout}
       
      />
      
      <p>Result: {ReactHtmlParser(this.state.result)} </p>
      <hr />
      <input type="button" value="next!"  onClick={this.checkq}/>
      </div>
      </div>
      
    )

  }
  playSound(url) {
    console.log("http://127.0.0.1/audio/"+url+".wav")
    var a = new Audio("http://127.0.0.1/audio/"+url+".wav");
    a.play();
  }
  sbut() {
    const mode = this.state.mode;
    if(mode == 1){
      this.setState({mode:0})

    }
    else{
      this.setState({mode:1})
    }
    
  }
  
  dstats() {
    return (
      <div>
      <div className='question'>
      <p>Question num {this.state.index} from 20</p>
    <p>Correct answers: {this.state.correct} and Failed answers: {this.state.failed}</p>
      </div>
      </div>
      
    )
  }


  componentWillUnmount() {

  }
  
  render() {
    if(this.state.mode === 0){
      return(
        <div>
          <div>
            {this.getq()}
          </div>
          <div>
            <input type="button" className='switch' onClick={this.sbut} value='writing mode'></input>
          </div>
          <div><div>{this.dstats()}</div></div>
        </div>
      )
    }
    else{
      return(
        <div>
          <div>
          {this.getw()}
          </div>
          <div><input type="button" className='switch' onClick={this.sbut} value='quiz mode'></input></div>
          <div>{this.dstats()}</div>
        </div>
      )
    }
  }
}

export default App;