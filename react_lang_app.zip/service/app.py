from flask import Flask, redirect, url_for, request, render_template, make_response, session, abort, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from flask_cors import CORS, cross_origin

from model.word import db, Word, Translation, Category, Question_result
app = Flask(__name__)

cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'

app.secret_key = 'XYZ'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://lab:lab@localhost/hermes'
db.init_app(app)


import random, time

def gen_question(words_data, failed_words=[]):

    if failed_words:
        valid_answer = random.choice(failed_words)
        failed_words.remove(valid_answer)
    else:
        valid_answer = random.choice(words_data)
        words_data.remove(valid_answer)
    answers = ["a","b","c","d"]
    
    valid_answer_letter = random.choice(answers)
    test_question = {
        "question":valid_answer["word"],
        valid_answer_letter:valid_answer["translation"]
    }
    answers.remove(valid_answer_letter)

    test_question[valid_answer_letter] = {"option":valid_answer["translation"], "sound":valid_answer["sound"], "id":valid_answer["id"]}
    option_1 = random.choice(words_data)
    words_data.remove(option_1)

    new_answer=random.choice(answers)
    test_question[new_answer] = {"option":option_1["translation"],"sound":option_1["sound"], "id":option_1["id"]}
    answers.remove(new_answer)


    option_2 = random.choice(words_data)
    words_data.remove(option_2)
    new_answer=random.choice(answers)
    test_question[new_answer] = {"option":option_2["translation"],"sound":option_2["sound"], "id":option_2["id"]}
    answers.remove(new_answer)

    option_3 = random.choice(words_data)
    words_data.remove(option_3)
    new_answer=random.choice(answers)
    test_question[new_answer] = {"option":option_3["translation"],"sound":option_3["sound"], "id":option_3["id"]}
    answers.remove(new_answer)
    words_data.append(option_1)
    words_data.append(option_2)
    words_data.append(option_3)
    return test_question

def gen_test(words_data, lim=20, failed_words=[]):
    test_questions = []

    for i in range(0,lim):
        
        question = gen_question(words_data,failed_words)
        test_questions.append(question)

    return test_questions


@app.route('/check', methods=['POST'])
def check_answer():
    requestJson = request.get_json(force=True)


    word =   requestJson["option"]
    translation =   requestJson["translation"]
    user_id =   requestJson["user_id"]
    lang =   requestJson["lang"]


    w = db.session.query(
        Word,
        Translation
    ).filter(Word.id==Translation.word_id
    ).filter(Word.word==word
    ).filter(Translation.word_id==translation).all()
    word_id = db.session.query(Word).filter(Word.word==word).first()
    word_id = word_id.id
    if not w:
        i = Question_result(
            word_id=word_id, 
            translation_id=translation, 
            result=False,
            lang=lang,
            user_id=user_id,
            date=time.strftime('%Y-%m-%d %H:%M:%S')

        )
        db.session.add(i)
        db.session.commit()
        return jsonify({"result":False})
        # add to failed words
    else:
        i = Question_result(
            word_id=word_id, 
            translation_id=translation, 
            result=True,
            lang=lang,
            user_id=user_id,
            date=time.strftime('%Y-%m-%d %H:%M:%S')

        )
        db.session.add(i)
        db.session.commit()
        return jsonify({"result":True})

@app.route('/failed_words', methods=['GET'])
def failed_words():
    previous= db.session.execute("""

    SELECT word.id,word, translation.translation , 
        (select count(question_result.id) 
            from question_result where question_result.result = 0 and question_result.word_id = word.id) / count(question_result.result) as err_avg
    from question_result, word, translation where word.id = question_result.word_id and translation.word_id = word.id group by word.id order by err_avg desc
    """)

    if previous.rowcount > 0:
        failed_words = []
        for p in previous:
            avge = (p[-1])
            if avge >= 0.1:
                w = {
                    "id":p[0],
                    "word":p[1],
                    "translation":p[2],
                    "sound":"audio/"+str(p[0])+".wav"
                }
                failed_words.append(w)
    
    return jsonify(failed_words)

@app.route('/gentest/<category>', methods=['GET'])
def make_test(category: str):
    cat = category
    words = db.session.query(
        Word, 
        Category, 
        Translation
    ).filter(Category.category==cat
    ).filter(Word.id==Category.word_id 
    ).filter(Word.id == Translation.word_id)
    words_list = []
    for w in words:
        w_obj = {
            "word":w.Word.word,
            "translation":w.Translation.translation,
            "sound":w.Translation.sound,
            "id":w.Word.id
        }
        words_list.append(w_obj)

    previous= db.session.execute("""

    SELECT word.id,word, translation.translation , 
        (select count(question_result.id) 
            from question_result where question_result.result = 0 and question_result.word_id = word.id) / count(question_result.result) as err_avg
    from question_result, word, translation where word.id = question_result.word_id and translation.word_id = word.id group by word.id order by err_avg desc
    """)
    
    
    if previous.rowcount > 0:
        failed_words = []
        for p in previous:
            avge = (p[-1])
            if avge >= 0.3:
                w = {
                    "id":p[0],
                    "word":p[1],
                    "translation":p[2],
                    "sound":"audio/"+str(p[0])+".wav"
                }
                failed_words.append(w)
        if len(failed_words) > 20:
            new_questions = gen_test(words_list, failed_wordslist[:20], 20)
            return jsonify(test_questions+new_questions)
        elif len(failed_words) == 20:
            new_questions = gen_test(words_list, 20, failed_words)
            return jsonify(new_questions)
        else:
            test_questions = gen_test(words_list, 20-len(failed_words))
            new_questions = gen_test(words_list, len(failed_words), failed_words)
            return jsonify(test_questions+new_questions)

    else:
        test_questions = gen_test(words_list)
        return jsonify(test_questions)

   
