
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

class Word(db.Model):
    id = db.Column('id', db.Integer, primary_key = True)
    word = db.Column('word', db.String())
    
class Translation(db.Model):
    id = db.Column('id', db.Integer, primary_key = True)
    word_id = db.Column('word_id', db.Integer, db.ForeignKey("word.id"))
    lang = db.Column('lang', db.String())
    translation = db.Column('translation', db.String())
    sound = db.Column('sound', db.String())

class Category(db.Model):
    id = db.Column('id', db.Integer, primary_key = True)
    word_id = db.Column('word_id', db.Integer, db.ForeignKey("word.id"))
    category = db.Column('category', db.String())

class User(db.Model):
    id = db.Column('id', db.Integer, primary_key = True)
    username = db.Column('username', db.String())
    password = db.Column('password', db.String())
class Question_result(db.Model):
    id = db.Column('id', db.Integer, primary_key = True)
    word_id = db.Column('word_id', db.Integer, db.ForeignKey("word.id"))
    translation_id = db.Column('translation_id', db.Integer, db.ForeignKey("translation.id"))
    user_id = db.Column('user_id', db.Integer, db.ForeignKey("user.id"))
    date = db.Column('date', db.Date)
    result = db.Column('result', db.Boolean)
    lang = db.Column('lang', db.String())
