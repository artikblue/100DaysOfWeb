import requests


url = "http://0.0.0.0:5000/check"

p_data = {
    "option":"famous",
    "translation":1,
    "user_id":1,
    "lang":"ru"
}

r = requests.post(url=url, data=p_data)

print(r.text)