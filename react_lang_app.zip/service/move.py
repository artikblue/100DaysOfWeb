
import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="lab",
  password="lab",
  database="hermes"
)

mycursor = mydb.cursor()


def insert_word(mydb, mycursor, word, translate, i):
    # insert the word
    sql = "INSERT INTO word (id, word) VALUES (%s,%s)"
    val = (i, word)
    mycursor.execute(sql, val)
    mydb.commit()

    # insert meaning
    sql = "INSERT INTO translation (id, word_id, lang, translation, sound) VALUES (%s,%s,%s,%s,%s)"
    val = (i, i, "ru", translate, "audio/"+str(i)+".wav")
    mycursor.execute(sql, val)
    mydb.commit()

    # link_category
    sql = "INSERT INTO category (id, word_id, category) VALUES (%s,%s,%s)"
    val = (i, i, "a1_a2")
    mycursor.execute(sql, val)
    mydb.commit()




i = 0
with open("words_a1_a2_ru.txt", "r") as f:
    for line in f:
        i += 1
        if len(line) > 2:
            l = line.split(":")
            insert_word(mydb, mycursor, l[0], l[1][:-1], i)